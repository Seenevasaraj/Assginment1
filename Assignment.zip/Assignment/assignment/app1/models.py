from django.db import models
import datetime

# Create your models here.

class Department(models.Model):
    college_name=models.CharField(max_length=100)
    department_name=models.CharField(max_length=100)

    def __str__(self):
        return self.department_name

class Faculty(models.Model):
    Faculty_name=models.CharField(max_length=100)
    department_name=models.ForeignKey(Department,on_delete=models.CASCADE)
    joining_date=models.DateField(default=datetime.date.today)

    def __str__(self):
        return self.Faculty_name
