from django.shortcuts import render
from app1.forms import *
from app1.models import *
import xlwt
from django.http import HttpResponse

# Create your views here.

def index(request): 
    return render(request,'home.html')




def register(request):       

	registered=False
	if request.method=='POST':        
		user_form=RegisterForm(data=request.POST)           

		if user_form.is_valid :
			user=user_form.save()
			user.save()
			
		else:
		    print(user_form.errors)

	else:
		user_form=RegisterForm()                
    

	return render(request,'app_user/register.html',
		{'registered':registered,
		'user_form':user_form,
        'department_name':Department.objects.all(),
		})																				


def export_users_xls(request):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="users.xls"'

    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Users Data') 

    row_num = 0

    font_style = xlwt.XFStyle()
    font_style.font.bold = True

    columns = ['Faculty','Department' ]

    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], font_style) 

    font_style = xlwt.XFStyle()
    
    rows =Faculty.objects.all().values_list('Faculty_name','department_name').order_by('joining_date')

    for row in rows:
        gt=Department.objects.get(id=row[1])
        d=gt.department_name
        gt2=(row[0],d)
        row_num += 1
        for col_num in range(len(gt2)):
            ws.write(row_num, col_num, gt2[col_num], font_style)

    wb.save(response)

    return response
