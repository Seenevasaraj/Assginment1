from django.contrib import admin
from app1.models import *

# Register your models here.

admin.site.register(Department)
admin.site.register(Faculty)