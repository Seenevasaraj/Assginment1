from django import forms
from app1.models import *


class RegisterForm(forms.ModelForm):
    Faculty_name=forms.CharField()
    department_name=forms.CharField()
    joining_date=forms.DateField()
    class Meta:
        model=Faculty
        fields=('Faculty_name','department_name','joining_date')
